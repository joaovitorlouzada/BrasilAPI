import React, { useState } from 'react';
import BrokerCatalog from './components/BrokerCatalog';
import ZipCodeSearcher from './components/ZipCodeSearcher';
import './App.css';

function App() {
  const [activeView, setActiveView] = useState('brokers'); // Inicia com Corretoras

  const renderView = () => {
    switch (activeView) {
      case 'brokers':
        return <BrokerCatalog />;
      case 'cep':
        return <ZipCodeSearcher />;
      default:
        return <h2>Selecione uma opção acima.</h2>;
    }
  };

  return (
    <div className="App">
      {/* 1. SEÇÃO HERO (OCUPA A TELA TODA, IGNORANDO O PADDING DO .App) */}
      <section className="hero" id="inicio">
        <div className="hero-inner">
          <div className="hero-content">
            <h1 className="hero-title">Projeto Brasil API</h1>
            <p className="hero-subtitle">Bem-vindo ao projeto que conecta APIs para um novo mundo digital.</p>
          </div>
          <div className="hero-media">
            <img src="BrasilAPI-logo.png" alt="Imagem de fundo Brasil" className="hero-image" />
          </div>
        </div>
        <div className="hero-wave"></div> {/* Wave */}
      </section>

      {/* 2. CONTEÚDO PRINCIPAL (DENTRO DO NOVO WRAPPER COM PADDING E FUNDO BRANCO) */}
      <div className="main-content-wrapper"> 
        <h1>Projeto Node-RED & React (Teste Técnico)</h1>
        <p>O front-end React está consumindo os endpoints do Node-RED na porta 1880.</p>

        <div className="navigation-controls">
          <button 
            onClick={() => setActiveView('brokers')}
            className={activeView === 'brokers' ? 'active' : ''}
          >
            🇧🇷 Catálogo de Corretoras
          </button>

          <button 
            onClick={() => setActiveView('cep')}
            className={activeView === 'cep' ? 'active' : ''}
          >
            📍 Buscador de CEP
          </button>
        </div>

        <hr />
        <div className="content-container">
          {renderView()}
        </div>
      </div>
    </div>
  );
}

export default App;